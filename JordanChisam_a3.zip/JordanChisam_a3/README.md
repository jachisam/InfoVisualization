I used external resources

- http://bl.ocks.org/weiglemc/6185069
- Previous assignments of mine that have resources cited in the old README.md


Everything I used to run the sentiment analysis can be found in the /python folder.
My understanding of approaching this came from CSE 427S.
I adapted previous Java code to be executed in python.
