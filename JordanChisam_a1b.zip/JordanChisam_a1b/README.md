Assignment 1b

I used external resources:

    - https://www.quora.com/How-do-you-get-all-of-the-child-elements-within-a-DIV-in-Javascript (used in staircase())
    - https://stackoverflow.com/questions/14422198/how-do-i-remove-all-children-elements-from-a-node-and-then-apply-them-again-with (used in update(error, data))
    - http://www.petercollingridge.co.uk/tutorials/svg/interactive/mouseover-effects/

I implemented the tooltip for extra credit. I used the link below for reference.
    - http://bl.ocks.org/williaster/af5b855651ffe29bdca1 (tooltip reference)

I did not finish the transitions extra credit option.




# for python 3
python -m http.server 8080
