##Assignment 1b

I used external resources:

### Year Chart
  - http://jonathansoma.com/tutorials/d3/clicking-and-hovering/

### Electoral Vote Chart
  - http://knowledgestockpile.blogspot.com/2012/01/understanding-selectall-data-enter.html?m=1
  - https://www.dashingd3js.com/svg-group-element-and-d3js
  - https://stackoverflow.com/questions/21709139/how-to-add-an-attribute-to-an-existing-svgg-tag-on-leaflet-map

### Vote Percentage chart


### Tile chart
  - https://stackoverflow.com/questions/17410082/appending-multiple-svg-text-with-d3

### Brush Selection
  - Did not complete the extra credit




# for python 3
python -m http.server 8080
